Install this version of ImageJ
Then install mri-plugins-base
then mri-all-plugins